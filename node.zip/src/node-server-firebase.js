/**
 * CakraNode - Bot Node Server (Firebase Realtime Version)
 * Real-time communication using Firebase Realtime Database
 */

import os from 'os';
import bedrock from 'bedrock-protocol';
import dotenv from 'dotenv';
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, onValue, set, push, update, onChildAdded } from 'firebase/database';

dotenv.config();

// Firebase config
const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN,
  databaseURL: process.env.FIREBASE_DATABASE_URL,
  projectId: process.env.FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID,
};

// Configuration
const CONFIG = {
  apiUrl: process.env.API_URL || 'http://localhost:3000',
  accessToken: process.env.ACCESS_TOKEN,
  nodeIp: process.env.NODE_IP || 'auto',
  proxyHost: process.env.PROXY_HOST || null,
  proxyPort: process.env.PROXY_PORT ? parseInt(process.env.PROXY_PORT) : null,
  proxyUsername: process.env.PROXY_USERNAME || null,
  proxyPassword: process.env.PROXY_PASSWORD || null,
};

const botClients = new Map();
let nodeId = null;
let db = null;

// Logger
function getTimestamp() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
}

function logInfo(msg) { console.log(`[${getTimestamp()}] [INFO]: ${msg}`); }
function logWarn(msg) { console.log(`[${getTimestamp()}] [WARN]: ${msg}`); }
function logError(msg) { console.log(`[${getTimestamp()}] [ERROR]: ${msg}`); }
function logServer(msg) { console.log(`[${getTimestamp()}] [SERVER]: ${msg}`); }

// Firebase operations
function initFirebase() {
  const app = initializeApp(firebaseConfig);
  db = getDatabase(app);
  logInfo('Firebase initialized');
}

function listenForCommands() {
  const commandsRef = ref(db, `nodes/${nodeId}/commands`);
  
  onChildAdded(commandsRef, async (snapshot) => {
    const command = snapshot.val();
    const commandId = snapshot.key;
    
    logInfo(`New command received: ${command.action}`);
    
    // Process command
    await processCommand(command, commandId);
    
    // Remove processed command
    await set(ref(db, `nodes/${nodeId}/commands/${commandId}`), null);
  });
  
  logInfo('Listening for commands on Firebase...');
}

async function updateNodeStatus(data) {
  try {
    await set(ref(db, `nodes/${nodeId}/status`), {
      ...data,
      lastUpdate: Date.now(),
    });
  } catch (err) {
    logError(`Failed to update node status: ${err.message}`);
    if (err.code === 'PERMISSION_DENIED') {
      logError('❌ Firebase Rules Error! Follow these steps:');
      logError('1. Open: https://console.firebase.google.com/');
      logError('2. Select your project');
      logError('3. Go to: Realtime Database → Rules');
      logError('4. Replace with: { "rules": { ".read": true, ".write": true } }');
      logError('5. Click Publish');
      logError('6. Restart this server');
      process.exit(1);
    }
  }
}

async function updateBotStatus(botId, status, error = null) {
  try {
    await set(ref(db, `bots/${botId}/status`), {
      status,
      error,
      timestamp: Date.now(),
    });
  } catch (err) {
    logError(`Failed to update bot status: ${err.message}`);
  }
}

async function addBotLog(botId, logType, message) {
  try {
    const logsRef = ref(db, `bots/${botId}/logs`);
    await push(logsRef, {
      log_type: logType,
      message,
      timestamp: Date.now(),
    });
  } catch (err) {
    logError(`Failed to add bot log: ${err.message}`);
  }
}

// Send heartbeat every 10 secondsa
function startHeartbeat() {
  setInterval(async () => {
    const stats = getSystemStats();
    await updateNodeStatus({
      online: true,
      stats,
    });
  }, 10000);
  
  logInfo('Heartbeat started (10s interval)');
}

// Get system stats
function getSystemStats() {
  const cpus = os.cpus();
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  
  let totalIdle = 0, totalTick = 0;
  cpus.forEach((cpu) => {
    for (const type in cpu.times) totalTick += cpu.times[type];
    totalIdle += cpu.times.idle;
  });
  
  const idle = totalIdle / cpus.length;
  const total = totalTick / cpus.length;
  const cpuUsage = 100 - Math.floor((idle / total) * 100);
  
  return {
    cpu_usage: cpuUsage,
    ram_used: totalMemory - freeMemory,
    ram_total: totalMemory,
    bot_count: botClients.size,
  };
}

// Register node
async function registerNode() {
  if (!CONFIG.accessToken) {
    logError('ACCESS_TOKEN is required! Get it from: https://cakranode.vercel.app/dashboard/nodes');
    logError('Steps:');
    logError('1. Login as admin');
    logError('2. Go to Nodes page');
    logError('3. Click "Create Node"');
    logError('4. Copy the token and add to .env: ACCESS_TOKEN=cn-...');
    process.exit(1);
  }
  
  try {
    const response = await fetch(`${CONFIG.apiUrl}/api/node/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        access_token: CONFIG.accessToken,
        ip_address: CONFIG.nodeIp,
      }),
    });
    
    const data = await response.json();
    if (data.success) {
      nodeId = data.node.id;
      logInfo(`Node registered: ${data.node.name} (${nodeId})`);
      return true;
    }
    logError(`Failed to register: ${data.error}`);
    return false;
  } catch (err) {
    logError(`Registration error: ${err.message}`);
    return false;
  }
}

// Process command
async function processCommand(command, commandId) {
  logInfo(`Processing: ${command.action} for bot ${command.bot_id || 'N/A'}`);
  
  try {
    let result = {};
    
    switch (command.action) {
      case 'create':
      case 'start':
        result = await startBot(command);
        break;
      case 'stop':
        result = await stopBot(command);
        break;
      case 'restart':
        await stopBot(command);
        await new Promise(r => setTimeout(r, 2000));
        result = await startBot(command);
        break;
      case 'delete':
        result = await stopBot(command);
        break;
      default:
        result = { error: `Unknown action: ${command.action}` };
    }
    
    // Update command result in Firebase
    await set(ref(db, `commands/${commandId}/result`), {
      status: result.error ? 'failed' : 'completed',
      result,
      timestamp: Date.now(),
    });
  } catch (err) {
    logError(`Command error: ${err.message}`);
    await set(ref(db, `commands/${commandId}/result`), {
      status: 'failed',
      result: { error: err.message },
      timestamp: Date.now(),
    });
  }
}

// Start bot
async function startBot(command) {
  const { bot_id, payload } = command;
  const { username, server_ip, server_port, offline_mode } = payload;
  
  if (botClients.has(bot_id)) {
    return { message: 'Bot already running', username };
  }
  
  logInfo(`Starting: ${username} -> ${server_ip}:${server_port}`);
  
  const clientOptions = {
    host: server_ip,
    port: server_port || 19132,
    username,
    offline: offline_mode !== false,
  };
  
  const client = bedrock.createClient(clientOptions);
  
  botClients.set(bot_id, {
    client,
    username,
    connected: false,
  });
  
  client.on('spawn', () => {
    logInfo(`[${username}] Spawned!`);
    const bot = botClients.get(bot_id);
    if (bot) bot.connected = true;
    updateBotStatus(bot_id, 'running');
  });
  
  client.on('disconnect', (packet) => {
    logWarn(`[${username}] Disconnected: ${packet?.message || 'Unknown'}`);
    updateBotStatus(bot_id, 'error', packet?.message);
  });
  
  client.on('text', (packet) => {
    if (packet?.message) {
      const msg = packet.message.replace(/§[0-9a-zA-Z]/gi, '');
      logServer(`[${username}] ${msg}`);
      addBotLog(bot_id, 'server', msg);
    }
  });
  
  return { message: 'Bot started', username };
}

// Stop bot
async function stopBot(command) {
  const { bot_id } = command;
  const bot = botClients.get(bot_id);
  
  if (!bot) return { message: 'Bot not found' };
  
  logInfo(`Stopping: ${bot.username}`);
  if (bot.client) bot.client.close();
  botClients.delete(bot_id);
  
  updateBotStatus(bot_id, 'stopped');
  return { message: 'Bot stopped', username: bot.username };
}

// Main
async function main() {
  logInfo('=== CakraNode - Firebase Realtime Version ===');
  
  const registered = await registerNode();
  if (!registered) {
    logError('Failed to register, retrying in 30s...');
    setTimeout(main, 30000);
    return;
  }
  
  logInfo('Node registered, initializing Firebase...');
  initFirebase();
  
  // Set node online
  await updateNodeStatus({ online: true, stats: getSystemStats() });
  
  // Start listening for commands
  listenForCommands();
  
  // Start heartbeat
  startHeartbeat();
  
  logInfo('Firebase node server running!');
}

main();
